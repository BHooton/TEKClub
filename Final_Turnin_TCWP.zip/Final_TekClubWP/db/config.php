<?php

$hn = 'localhost';
$db = 'tekclub';
$un = 'root';
$pw ='';