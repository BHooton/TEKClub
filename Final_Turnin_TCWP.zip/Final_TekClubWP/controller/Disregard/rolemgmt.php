<?php

session_start();

if(!isset($_SESSION['UtahID']) && $_SESSION['token'] != ''){
    header ("Location: loginform.php");
    exit; // stop further executing, very important
}
?>
