<!DOCTYPE html>
<?php

include_once 'Menu.php';

?>
<html>
    <head>
        <title>Access Denied</title>
    </head>
    <body>
        <br>
        <br>
        <br>
        <br>
        <br>
        <div style="text-align:center; color: black;font-family: 'Montserrat', sans-serif; font-weigh: bold; font-size: 250%;">
            <h1>Access Denied: You do not have the correct user privledges to view this content.</h1>
        </div>
        <br>
        <br>
        <br>
        <br>
        <div align="center">
			<img src='../imgs/MainTekLogo.png' alt='logo'>
		</div>
		<br>
		<div align="center">
			<img src='../imgs/SFEBBLogo.png' alt='SFEBB'>
		</div>
    </body>
</html>