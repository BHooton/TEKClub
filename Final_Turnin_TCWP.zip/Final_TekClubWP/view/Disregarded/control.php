<?php

require_once '../db/config.php';
require_once '../backend/d'

?>




    /*"<nav id='main_nav' class='navbar navbar-default'>".
            "<div class='container-fluid'>".
            "<div class='navbar-header'>".
            "<a id='logo' href='#'>TEK CLUB</a>".
            "<ul class='nav navbar-nav'>".
			    "<li class='active'><a href='index.php'>Home</a></li>".
			    "<li class='dropdown'>".
				    "<a class='dropdown-toggle' data-toggle='dropdown' href='#'>Student".
				    "<span class='caret'></span></a>".
				    "<ul class='dropdown-menu'>".
					    "<li><a href='signup.php'>Sign Up</a></li>".
					    "<li><a href='loginform.php'>Login</a></li>".
					    "<li><a href='calendar_final.php'>Calendar</a></li>".
                        "<li><a href='RSVP.php'>RSVP</a><li>".
					    "<li><a href='annoucements.php'>Annoucements</a></li>".
					    "<li><a href='gallery.php'>Photos</a></li>".
                        "<li><a href='eventSuggestion.php'>Event Suggestion</a></li>".
				    "</ul>".
			    "</li>".
			    "<li class='dropdown'>".
				    "<a class='dropdown-toggle' data-toggle='dropdown' href='#'>Alumni".
                    "<span class='caret'></span></a>".
				    "<ul class='dropdown-menu'>".
                        "<li><a href='signup.php'>Sign Up</a></li>".
					    "<li><a href='loginform.php'>Login</a></li>".
					    "<li><a href='calendar_final.php'>Calendar</a></li>".
					    "<li><a href='annoucements.php'>Annoucements</a></li>".
					    "<li><a href='gallery.php'>Photos</a></li>".
                        "<li><a href='eventSuggestion.php'>Event Suggestion</a></li>".
				    "</ul>".
			    "</li>".
                "<li class='dropdown'>".
				    "<a class='dropdown-toggle' data-toggle='dropdown' href='#'>Officers".
				    "<span class='caret'></span></a>".
				    "<ul class='dropdown-menu'>".
                        "<li><a href='viewRSVP.php'>View RSVPs</a></li>".
					    "<li><a href='bannedUsers.php'>Banned List</a></li>".
					    "<li><a href='submitIMG.php'>Upload Image</a></li>".
					    "<li><a href='viewapplications.php'>Review Appliations</a></li>".
					    "<li><a href='es_view.php'>View Event Suggestion</a></li>".
                        "<li><a href='messageview.php'>View Messages</a></li>".
                        "<li><a href='leadershiproster.php'>Leadership Roster</a></li>".
				    "</ul>".
			    "</li>".
			    "<li class='dropdown'>".
                    "<a class='dropdown-toggle' data-toggle='dropdown' href='#'>Contact Information".
                    "<span class='caret'></span></a>".
                    "<ul class='dropdown-menu'>".
                        "<li><a href='messages.php'>Send us a Message</a></li>".
                        "<li><a href='applyleadership.php'>Apply to be an Officer</a></li>".
                    "</ul>".
                "</li>".
                "<li>".
                "<li class='active' style='float:right'><a href='logout.php'>Logout</a></li>".
            "</ul>".
    "</nav>";

    else
        echo ("<br><nav>".
                "<ul class='menu>".
                    "<li><a href='index.php'>Home</li>".
                    "<li><a href='signup.php'>Sign Up</li>".
                    "<li><a href='loginform.php'>Login</li>".
                    "<li><a href='contact.php'>Contact Us</li>".
                "</ul>".
            "<br>".
                "<span class='info'>&#8658; You must be logged in to "."view this page.</span><br><br>");
                
            "<section id='header' class='jumbotron text-center'>".
                "<h1 class='display-3'>View Member Messages</h1>".
                    "<p class='lead'>Below are messages submitted by TEK Club Members</p>".
                    "<a href='loginform.php' class='btn btn-primary'>Login</a>".
                    "<a href='signup.php' class='btn btn-success'>Join The Club</a>".
            "</section>";
?>*/

