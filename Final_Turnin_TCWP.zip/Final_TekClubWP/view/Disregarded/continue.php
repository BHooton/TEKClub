<?php

require_once '../backend/User.php';
$page_role = array('admin');

session_start();

if(isset($_SESSION['username'])){
    $user = $_SESSION['UtahID'];
    //$username = $user->username;
    $user_roles = $user->getRoles();
    $password = $_SESSION['pwd'];

    $found=0;
    foreach($user_roles as $urole){
        foreach($page_role as $prole){
            if($urole == $prole) $found=1;
        }
    }

    if($found==1){
        echo "Welcome back $username with $password";
    }else{
        header("Location: unathorized.php");
    }
}

/*
$UtahID = $_SESSION['UtahID'];
$password = $_SESSION['pwd'];

echo $UtahID;
echo '<br>';
echo $pwd;
*/

destroy_session_and_data();

function destroy_session_and_data(){
    $_SESSION = array();
    setcookie(session_name(), '', time()-2592000, '/');
    session_destroy();
}

?>