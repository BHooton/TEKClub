<!doctype html>
<html>
<?php
require_once 'header.php';
	?>
<head>
  <title>Calendar</title>
  <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,300,400,700" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <link rel="stylesheet" href="../frontend/album.css">
</head>

<body>
<nav class="navbar navbar-default">
	<div class="container-fluid">
		<div class="navbar-header">
		</div>
		<ul class="nav navbar-nav">
			<li class="active"><a href="home.php">Home</a></li>
			<li class="dropdown">
				<a class="dropdown-toggle" data-toggle="dropdown" href="#">Student
				<span class="caret"></span></a>
				<ul class="dropdown-menu">
					<li><a href="signup.php">Sign Up</a></li>
					<li><a href="loginform.php">Login</a></li>
					<li><a href="calendar.php">Calendar</a></li>
					<li><a href="annoucements.php">Annoucements</a></li>
					<li><a href="gallery.php">Photos</a></li>
				</ul>
			</li>
			<li class="dropdown">
				<a class="dropdown-toggle" data-toggle="dropdown" href="#">Alumni
				<span class="caret"></span></a>
				<ul class="dropdown-menu">
					<li><a href="signup.php">Sign Up</a></li>
					<li><a href="loginform.php">Login</a></li>
					<li><a href="calendar.php">Calendar</a></li>
					<li><a href="annoucements.php">Annoucements</a></li>
					<li><a href="gallery.php">Photos</a></li>
				</ul>
			</li>
			<li><a href="contact.php">Contact Information</a></li>
		</ul>
	</div>
</nav>

  <section class="container-fluid">
    <div class="row" align-items-center>
    <div class="col-lg-6 mt-5">
      <h2 class="text-center">Test</h2>
    </div>
    <div class="col-lg-6 mt-5">
      <div class="d-none d-lg-block">
      <img class="img-fluid" src="#" alt="">
      </div>
    </div>
    </div>
  </section>

<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>

  </body>
</html>