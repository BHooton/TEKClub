<?php
//Kicked
require_once '../db/config.php';
require_once '../backend/Messages.php';
$page_roles = array('admin');

$conn = new mysqli($hn, $un, $pw, $db);
if ($conn->connect_error) die("Fatal Error");

if(isset($_GET['MessageID'])){
    $MessageID = $GET['MessageID'];
    
    $query = "SELECT * FROM contactform WHERE MessageID = '$MessageID'";

    $resutl = $conn->query($query);
    if(!$result) die($conn->error);

    $rows = $result->num_rows;

    for($j=0; $j<$rows;++$j){
        $result->data_seek($j);
        $row = $result->fetch_array(MYSQLI_NUM);
    
echo <<<_END

        <pre>
            MessageID: <a href='messages.php?MessageID=$row[0]'>$row[0]</a>
            Name: $row[1]
            Email: $row[2]
            Comment: $row[3]
        </pre>
        <form method='post' action='Messages.php'>
            <input type ='hidden' name = 'delete' value = 'yes'>
            <input type = 'hidden' name = 'MessageID' value ='$row[0]'>
            <input type = 'submit' value = 'Delete Message'>
        </form>
    _END;
    }
    $result->close();
    $conn->close();
    ?>