<!DOCTYPE html>
<!-- I believe Kicked -->
<?php


session_start();

if(!isset($_SESSION['UtahID']) && $_SESSION['token'] != ''){
    header ("Location: loginform.php");
    exit; // stop further executing, very important
}


require_once 'Menu.php';
//require_once 'footer.php';
	?>
<head>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
<nav class="navbar navbar-default">
	<div class="container-fluid">
		<div class="navbar-header">
		</div>
		<ul class="nav navbar-nav">
			<li class="active"><a href="home.php">Home</a></li>
			<li class="dropdown">
				<a class="dropdown-toggle" data-toggle="dropdown" href="#">Student
				<span class="caret"></span></a>
				<ul class="dropdown-menu">
					<li><a href="signup.php">Sign Up</a></li>
					<li><a href="loginform.php">Login</a></li>
					<li><a href="calendar_final.php">Calendar</a></li>
					<li><a href="annoucements.php">Annoucements</a></li>
					<li><a href="gallery.php">Photos</a></li>
                    <li><a href="eventSuggestion.php">Event Suggestion</a></li>
				</ul>
			</li>
			<li class="dropdown">
				<a class="dropdown-toggle" data-toggle="dropdown" href="#">Alumni
				<span class="caret"></span></a>
				<ul class="dropdown-menu">
					<li><a href="signup.php">Sign Up</a></li>
					<li><a href="loginform.php">Login</a></li>
					<li><a href="calendar.php">Calendar</a></li>
					<li><a href="annoucements.php">Annoucements</a></li>
					<li><a href="gallery.php">Photos</a></li>
                    <li><a href="eventSuggestion.php">Event Suggestion</a></li>
				</ul>
			</li>
            <li class="dropdown">
				<a class="dropdown-toggle" data-toggle="dropdown" href="#">Officers
				<span class="caret"></span></a>
				<ul class="dropdown-menu">
					<li><a href="signup.php">Banned List</a></li>
					<li><a href="loginform.php">Upload Image</a></li>
					<li><a href="calendar.php">Review Appliations</a></li>
					<li><a href="annoucements.php">View Event Suggestion</a></li>
				</ul>
			</li>
			<li><a href="contact.php">Contact Information</a></li>
		</ul>
	</div>
</nav>

<section id="header" class="jumbotron text-center">
        <h1 class="display-3">View Member Messages</h1>
        <p class="lead">Below are messages submitted by TEK Club Members</p>
        <a href="loginform.php" class="btn btn-primary">Login</a>
        <a href="signup.php" class="btn btn-success">Join The Club</a>
    </section>

<h1 style="text-align:center;">Add Users to the TEK Club Banned List</h1>

<div>
    <p>
        Please fill in the following information to submit your RSVP for an upcoming TEK Event. This form is for members who break club protocols and can no longer attend sponsered events.
    </p>
</div>

<br>
<br>

<h3> Banned List:</h3>
</body>
</html>
