<!DOCTYPE html>
<?php

//Start User Session
session_start();

//Include packages
echo "<!DOCTYPE html><html><head>".
        "<link rel='stylesheet' type='text/css' href='../frontend/navbar.css'>".
        "<link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css'>".
        
        "<script src='https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js'></script>".
        "<script src='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js'></script>";

//reference DB & functions
require_once '../backend/QB.php';
require_once '../db/config.php';

//Placeholder pre-login
$userstr= ' (Guest)';

//Pull Session info
if(isset($_SESSION['UtahID']))
{
    $user = $_SESSION['UtahID'];
    $userFName = $_SESSION['FirstName'];
    $userLName = $_SESSION['LastName'];
    $loggedin = TRUE;
    $userstr = " ($userFName)";
   
}
else $loggedin = FALSE;//Login failed

if($loggedin)
        echo "<title>TEKClub: $userFName $userLName</title>".
    
  "</head>".
  
  "<body>".
  
    "<header>".
            "<button class='toggle-nav'>".
                  "<span>></span>".
            "</button>".
            "<ul class='nav'>".
                  "<li class='loud'><a href='index.php'>Home</a></li>".
                  "<li class='loud'><a href='members.php'>Members</a></li>".
                  "<li class='loud'><a href='calendar_final.php'>Events</a></li>".
                  "<li class='loud'><a href='officers.php'>Officers</a></li>".
                  "<li class='loud'><a href='loginform.php'>Login</a></li>".
                  "<li class='loud'><a href='logout.php'>Logout</a></li>".
                  "<li class='loud'><a href='contact.php'>Contact</a></li>".
            "</ul>".
      "</header>";
      else echo("<br>".
      "<button class='toggle-nav'>".
                  "<span>></span>".
            "</button>".
            "<ul class='nav'>".
                  "<li class='loud'><a href='index.php'>Home</a></li>".
                  "<li class='loud'><a href='members.php'>Members</a></li>".
                  "<li class='loud'><a href='calendar_final.php'>Events</a></li>".
                  "<li class='loud'><a href='officers.php'>Officers</a></li>".
                  "<li class='loud'><a href='loginform.php'>Login</a></li>".
                  "<li class='loud'><a href='logout.php'>Logout</a></li>".
                  "<li class='loud'><a href='contact.php'>Contact</a></li>".
            "</ul>".

      "<span class='info'>&#8658; You must be logged in to "."view this page.</span><br><br>");

      "<section id='header' class='jumbotron text-center'>".
                "<h1 class='display-3'>View Member Messages</h1>".
                    "<p class='lead'>Below are messages submitted by TEK Club Members</p>".
                    "<a href='loginform.php' class='btn btn-primary'>Login</a>".
                    "<a href='signup.php' class='btn btn-success'>Join The Club</a>".
            "</section>";
  
  
  
    "<script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>".
    "<script  src='../frontend/navbar.js'></script>".
  "</body>".
  
  "</html>";
  ?>
    