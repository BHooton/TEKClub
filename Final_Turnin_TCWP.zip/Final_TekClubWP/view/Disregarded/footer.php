<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
.footer {
   
   left: 0;
   bottom: 0;
   width: 100%;
   font-family: 'Share Tech Mono', monospace;
   background-color: #990000 ;
   color: White;
   text-align: center;
   font-weight: bold;
}
</style>
</head>
<body>

<div style= 'background-color: #990000; text-align: center; font-weight: bold; color: white; width: 100%;' class="footer">
  <p>2018-2019 University of Utah TEK Club Chapter</p>
</div>

</body>
</html> 
