<!DOCTYPE html>
<?php

require_once 'footer.php';
require_once 'FinalMenu.php';
	?>
<head>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css">
    <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="../frontend/viewtable.css" type="text/css">
</head>
<body>
<!--<nav class="navbar navbar-default">
	<div class="container-fluid">
		<div class="navbar-header">
		</div>
		<ul class="nav navbar-nav">
			<li class="active"><a href="home.php">Home</a></li>
			<li class="dropdown">
				<a class="dropdown-toggle" data-toggle="dropdown" href="#">Student
				<span class="caret"></span></a>
				<ul class="dropdown-menu">
					<li><a href="signup.php">Sign Up</a></li>
					<li><a href="loginform.php">Login</a></li>
					<li><a href="calendar_final.php">Calendar</a></li>
					<li><a href="annoucements.php">Annoucements</a></li>
					<li><a href="gallery.php">Photos</a></li>
				</ul>
			</li>
			<li class="dropdown">
				<a class="dropdown-toggle" data-toggle="dropdown" href="#">Alumni
				<span class="caret"></span></a>
				<ul class="dropdown-menu">
					<li><a href="signup.php">Sign Up</a></li>
					<li><a href="loginform.php">Login</a></li>
					<li><a href="calendar.php">Calendar</a></li>
					<li><a href="annoucements.php">Annoucements</a></li>
					<li><a href="gallery.php">Photos</a></li>
				</ul>
			</li>
			<li><a href="contact.php">Contact Information</a></li>
		</ul>
	</div>
</nav>-->

<section id="header" class="jumbotron text-center">
        <h1 class="display-3">Suggested Events</h1>
        <p class="lead">Below are events suggested by members</p>
        <a href="loginform.php" class="btn btn-primary">Login</a>
        <a href="signup.php" class="btn btn-success">Join The Club</a>
    </section>

<p>Complete the following form to delete any suggest event entries</p><br>

<form method="post" action="es_view.php">
	Suggested Event ID<br>
	<input type="text" name="eID" placeholder="ID" required><br><br>
	Suggested Event Title<br>
    <input type="text" name="esTitle" placeholder="Title" required><br><br>
    Suggested Company<br>
    <input type="text" name="esCompany" placeholder="Company" required><br><br>
    <input type="submit" name="rsvp_submit" value="Delete"><br><br>
</form>
<h3>Suggested Event List:</h3>
</body>
</html>

<?php

require_once '../backend/View_ES.php';

// Create connection
require_once '../db/config.php';
$conn = new mysqli($hn, $un, $pw, $db);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

//Query to pull data from DB
$sql = "SELECT eID, esTitle, esDesc, esCompany FROM eventsuggestion";
$result = $conn->query($sql);

//Check if data is present in table
if ($result->num_rows > 0) {

    //format table and add header
    echo "<div class='container'>".
           "<h2>ENTER TITLE HERE</h2>".
            "<ul class='responsive-table>".

            "<li class='table-header'>".
            "<div class='col col-1'>eID</div>".
            "<div class='col col-2'>Suggested Title</div>".
            "<div class='col col-1'>Description</div>".
            "<div class='col col-1'>Company</div>".
            "</li>";

    // output data of each row
    while($row = $result->fetch_assoc()) {

       //Build Table for fetch_assoc data
        
       echo "<li class='table-row>\n".
                "<div class='col col-1' data-label='eID'>{$row['eID']}</div>".
                "<div class='col col-1' data-label='eID'>{$row['esTitle']}</div>".
                "<div class='col col-1' data-label='eID'>{$row['esDesc']}</div>".
                "<div class='col col-1' data-label='eID'>{$row['esCompany']}</div>";

        echo "</li>".
                "</ul>".
                "</div>";

       //echo '<tr>'."\n";
        //echo "<td>{$row['eID']}</td>\n" . "<td>{$row['esTitle']}</td>\n". "<td>{$row['esDesc']}</td>\n". "<td>{$row['esCompany']}</td>\n";
       // echo '</tr>'."\n";

    }
} else {
    //Tell user that DB is empty
    echo "0 results";
}
    ?>