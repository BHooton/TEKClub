$(document).ready(function(){

    var header = $('header'),
                btn    = $('button.toggle-nav');

    btn.on('click', function(){
          header.toggleClass('active');
    });

});